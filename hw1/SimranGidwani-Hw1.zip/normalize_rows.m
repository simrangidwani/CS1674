function [ output_args ] = normalize_rows( input_args )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


end